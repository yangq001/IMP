

spucal=function(a,ga){
  if(ga!=Inf){
    if(sum(a^ga)>=0){
      return((sum(a^ga))^(1/ga))
    }
    else{
      return((-sum(a^ga))^(1/ga))      
    }
  }
  else{
    return(max(abs(a)))
  }
}

spucal2=function(a,ga,t){
  if(ga!=Inf){
    if(sum(a[t,]^ga)>=0){
      return((sum(a[t,]^ga))^(1/ga))
    }
    else{
      return((-sum(a[t,]^ga))^(1/ga))      
    }
  }
  else{
    return(max(abs(a[t,])))
  }
}

findpara=function(b,dist){
  if(dist=="sgamma"){
    theta=var(b)/mean(b)
    k=var(b)/theta^2
    c=mean(b)-k*theta
    theta0=0
    while(abs(theta-theta0)>0.0001){
      theta0=theta
      k=var(b)/theta^2
      c=mean(b)-k*theta
      l=mean((b-c)^3)/(k*(k+1)*(k+2))
      if(l>0){
        theta=l^(1/3)        
      }
      else{
        theta=-(-l)^(1/3)
      }
    }
    c(k,theta,c)
    return(c(k,theta,c))
  }
  if(dist=="gamma"){
    theta=var(b)/mean(b)
    k=mean(b)/theta
    c(k,theta,c)
    return(c(k,theta))
  }
  if(dist=="gumbel"){
    ff2=c()
    ff2[2]=sqrt(6*var(b))/pi
    ff2[1]=mean(b)-ff2[2]*(-digamma(1))
    return(ff2)
  }
}


mcor=function(X){
  n1=dim(X)[2]
  C2=C0=cov(X)
  for(i in 1:n1){
    C2[i,i]=C2[i,i]+mean(abs(C0))/10
  }
  C3=C2
  for(i in 1:n1){
    for(j in 1:n1){
      C3[i,j]=C2[i,j]/sqrt(C2[i,i]*C2[j,j])
    }
  }
  return(C3)
}


#IMP combined
IMPaSPU=function(stZ,D,B,Ga,wga,ddd,method=1,div=5,enlarge=2){
  if(method==1){
    return(aimp2(stZ,D,B,Ga,wga,ddd))
  }
  if(method==2){
    return(aimp2r(stZ,D,B,Ga,wga,ddd))
  }  
  if(method==3){
    return(aimpW2(stZ,D,B,Ga,wga,ddd,div,enlarge))
  }    
}


#IMP with updated weights
aimpW2=function(stZ,D,B,Ga,wga,ddd,div=5,enlarge=2){
  wga1=wga
  # wga1=c(0.1,0.6,0.1,0.1,0.1)
  s1=Sys.time()
  B1=B/div
  wei=c()
  for(kw in 1:div){
    AS3=aimp0(stZ,D,B1,Ga,wga1,ddd)
    pw=AS3[[1]]
    wei=c(wei,AS3[[2]])
    a=which.min(pw)
    wga1[a]=wga1[a]*enlarge
    wga1=wga1/sum(wga1)
    if(kw==1){
      spu=AS3[[3]]
    }
    else{
      spu=rbind(spu,AS3[[3]][-1,])
    }
  }
  
  
  se=c()
  pspu=matrix(nrow=B+1,ncol=length(Ga))
  for(j in 1:length(Ga)){
    pspu[1,j]=sum(wei*(abs(spu[-1,j])>abs(spu[1,j])))/B 
    s=sum((wei*(abs(spu[-1,j])>abs(spu[1,j]))-pspu[1,j])^2)/(B-1)
    se[j]=sqrt(s/B)
  }
  spu1=abs(spu[-1,])
  for(j in 1:length(Ga)){
    rank2=rank(spu1[,j])
    wei2=wei[order(spu1[,j],decreasing=TRUE)]
    wei3=c(); wei3[1]=wei2[1]
    for(i in 2:(B-1)){
      wei3[i]=wei3[i-1]+wei2[i]
    }
    wei3=wei3/(B-1)
    wei3=c(0,wei3)
    wei4=wei3[B:1]
    pspu[2:(B+1),j]=wei4[rank2]
  }
  
  aspu=c()
  for(i in 1:(B+1)){
    aspu[i]=min(pspu[i,])
  }
  
  paspu=sum(wei*(aspu[-1]<aspu[1]))/B 
  s=sum((wei*(aspu[-1]<aspu[1])-paspu)^2)/(B-1)
  se[length(Ga)+1]=sqrt(s/B)
  
  c(pspu[1,],paspu);se
  
  s2=Sys.time()
  return(c(pspu[1,],paspu))
}


### IMP with fixed weights
aimp2=function(stZ,D,B,Ga,wga,ddd){
  s1=Sys.time()
  
  n=length(stZ)
  Sig=D
  soD=solve(D)
  eS <- eigen(D, symmetric = TRUE)
  ev <- eS$values
  CovSsqrt <- eS$vectors %*% diag(sqrt(pmax(ev, 0)), n)
  
  PP=matrix(nrow=B+1,ncol=length(Ga))
  
  wei=c()
  Z=matrix(nrow=B,ncol=n)
  
  mius=c()
  for(i in 1:length(Ga)){
    ga=Ga[i]
    if(ga<=2){
      #mius[i]=(abs(sum(stZ^ga)))^(1/ga)/ddd    ##WRONG!!!
      
      mius[i]=(abs(sum(stZ^ga))/length(stZ))^(1/ga)/ddd 
    }
    else{
      if(ga<Inf){
        mius[i]=(abs(sum(stZ^ga)))^(1/ga)/ddd      
      }
      else{
        mius[i]=max(abs(stZ))/ddd
      }
    }
  }
  
  #mius=mius*0   #aSPUs
  
  
  conM=list()
  conDsqrt=list()
  if(n>1){
    for(t in 1:n){
      S11=Sig[-t,-t]
      S12=Sig[-t,t]
      conM[[t]]=S12
      LL=S11-S12%*%t(S12)
      eS <- eigen(LL, symmetric = TRUE)
      ev <- eS$values
      LS <- eS$vectors %*% diag(sqrt(pmax(ev, 0)), n-1)
      conDsqrt[[t]]=LS
    }
  }
  
  aa=sample(1:length(Ga),B,prob=wga,replace=TRUE)
  tt=sample(1:n,B,replace=TRUE)
  pm=sample(c(-1,1),B,replace=TRUE)
  
  for(i in 1:B){
    a=aa[i]
    ga=Ga[a]
    
    if(ga<=2){
      z1=CovSsqrt%*%rnorm(n)+mius[a]*pm[i]
    }
    if(ga>2){
      z1=c()
      t=tt[i]
      z1[t]=rnorm(1)+mius[a]*pm[i]
      if(n>1){
        miunew=c(rep(0,n-1))+conM[[t]]*z1[t]
        Signew=conDsqrt[[t]]
        ll=c(1:n)[-t]
        z1[ll]=Signew%*%rnorm(n-1)+miunew
      }
    }
    Z[i,]=z1
  }
  
  #weight
  ww=matrix(nrow=B,ncol=length(Ga))
  x=t(Z)
  for(j in 1:length(Ga)){
    ga=Ga[j]
    if(ga<=2){
      #kua1=dmvnorm(x=Z[93198,], mean=miu, sigma=Sig, log = F)
      #kua2=dmvnorm(x=Z[93198,], mean=-miu, sigma=Sig, log = F)
      #kua3=dmvnorm(x=Z[93198,], mean=miu*0, sigma=Sig, log = F)
      #(kua1/kua3+kua2/kua3)/2  #checked
      
      #kua1=dmvnorm(x=Z[3,], mean=miu, sigma=Sig, log = T)
      #kua2=dmvnorm(x=Z[3,], mean=-miu, sigma=Sig, log = T)
      #kua3=dmvnorm(x=Z[3,], mean=miu*0, sigma=Sig, log = T)
      #(exp(kua1-kua3)+exp(kua2-kua3))/2  #checked
      
      miu=mius[j]
      miu=c(rep(miu,n))
      a=c(); b=c(); b2=c()
      mRm=t(miu)%*%soD%*%miu
      mR=t(miu)%*%soD
      mRZ=mR%*%t(Z)
      ww[,j]=as.vector(exp(-0.5*(mRm[1,1]-2*mRZ)))
      miu=-miu
      mRm=t(miu)%*%soD%*%miu
      mR=t(miu)%*%soD
      mRZ=mR%*%t(Z)
      ww[,j]=0.5*(ww[,j]+as.vector(exp(-0.5*(mRm[1,1]-2*mRZ))))
    }
    if(ga>2){
      br=mius[j]
      lll=exp((x^2-(x-br)^2)/2)
      lll2=exp((x^2-(x+br)^2)/2)      
      ww[,j]=0.5*(colMeans(lll)+colMeans(lll2))
    }
  }
  wei=1/ww%*%wga
  
  #p SPU
  spu=matrix(nrow=B+1,ncol=length(Ga))
  for(j in 1:length(Ga)){
    ga=Ga[j]
    if(ga<100){
      spu[1,j]=sum(stZ^ga)
      spu[-1,j]=rowSums(Z^ga)
    }
    else{
      spu[1,j]=max(abs(stZ))
      spu[-1,j]=apply(abs(Z),1,max)
    }
  }
  
  pspu=matrix(nrow=B+1,ncol=length(Ga))
  for(j in 1:length(Ga)){
    pspu[1,j]=sum(wei*(abs(spu[-1,j])>abs(spu[1,j])))/B   
  }
  spu1=abs(spu[-1,])
  for(j in 1:length(Ga)){
    rank2=rank(spu1[,j])
    wei2=wei[order(spu1[,j],decreasing=TRUE)]
    wei3=c(); wei3[1]=wei2[1]
    for(i in 2:(B-1)){
      wei3[i]=wei3[i-1]+wei2[i]
    }
    wei3=wei3/(B-1)
    wei3=c(0,wei3)
    wei4=wei3[B:1]
    pspu[2:(B+1),j]=wei4[rank2]
  }
  
  aspu=c()
  for(i in 1:(B+1)){
    aspu[i]=min(pspu[i,])
  }
  
  paspu=sum(wei*(aspu[-1]<aspu[1]))/B 
  
  s2=Sys.time()
  
  #return(list(c(pspu[1,],paspu),as.numeric(s2)-as.numeric(s1)))
  return(c(pspu[1,],paspu))
}



### IMP with fixed weights   different algorithm for SPU(1)
aimp2r=function(stZ,D,B,Ga,wga,ddd){
  s1=Sys.time()
  
  n=length(stZ)
  Sig=D
  soD=solve(D)
  eS <- eigen(D, symmetric = TRUE)
  ev <- eS$values
  CovSsqrt <- eS$vectors %*% diag(sqrt(pmax(ev, 0)), n)
  
  PP=matrix(nrow=B+1,ncol=length(Ga))
  
  wei=c()
  Z=matrix(nrow=B,ncol=n)
  
  mius=c()
  for(i in 1:length(Ga)){
    ga=Ga[i]
    if(ga<=2){
      #mius[i]=(abs(sum(stZ^ga)))^(1/ga)/ddd    ##WRONG!!!
      
      mius[i]=(abs(sum(stZ^ga))/length(stZ))^(1/ga)/ddd 
    }
    else{
      if(ga<Inf){
        mius[i]=(abs(sum(stZ^ga)))^(1/ga)/ddd      
      }
      else{
        mius[i]=max(abs(stZ))/ddd
      }
    }
  }
  
  #mius=mius*0   #aSPUs
  
  
  conM=list()
  conDsqrt=list()
  if(n>1){
    for(t in 1:n){
      S11=Sig[-t,-t]
      S12=Sig[-t,t]
      conM[[t]]=S12
      LL=S11-S12%*%t(S12)
      eS <- eigen(LL, symmetric = TRUE)
      ev <- eS$values
      LS <- eS$vectors %*% diag(sqrt(pmax(ev, 0)), n-1)
      conDsqrt[[t]]=LS
    }
  }
  
  aa=sample(1:length(Ga),B,prob=wga,replace=TRUE)
  tt=sample(1:n,B,replace=TRUE)
  pm=sample(c(-1,1),B,replace=TRUE)
  
  for(i in 1:B){
    a=aa[i]
    ga=Ga[a]
    
    if(ga<=2){
      if(ga==2){
        z1=CovSsqrt%*%rnorm(n)+mius[a]*pm[i]
      }else{
        llll1=t(t(as.vector(rep(1,n))))
        miu=D%*%llll1*abs(sum(stZ))/c((t(llll1)%*%D%*%llll1))
        z1=CovSsqrt%*%rnorm(n)+miu*pm[i]
      }
    }
    if(ga>2){
      z1=c()
      t=tt[i]
      z1[t]=rnorm(1)+mius[a]*pm[i]
      if(n>1){
        miunew=c(rep(0,n-1))+conM[[t]]*z1[t]
        Signew=conDsqrt[[t]]
        ll=c(1:n)[-t]
        z1[ll]=Signew%*%rnorm(n-1)+miunew
      }
    }
    Z[i,]=z1
  }
  
  #weight
  ww=matrix(nrow=B,ncol=length(Ga))
  x=t(Z)
  for(j in 1:length(Ga)){
    ga=Ga[j]
    if(ga<=2){
      #kua1=dmvnorm(x=Z[93198,], mean=miu, sigma=Sig, log = F)
      #kua2=dmvnorm(x=Z[93198,], mean=-miu, sigma=Sig, log = F)
      #kua3=dmvnorm(x=Z[93198,], mean=miu*0, sigma=Sig, log = F)
      #(kua1/kua3+kua2/kua3)/2  #checked
      
      #kua1=dmvnorm(x=Z[3,], mean=miu, sigma=Sig, log = T)
      #kua2=dmvnorm(x=Z[3,], mean=-miu, sigma=Sig, log = T)
      #kua3=dmvnorm(x=Z[3,], mean=miu*0, sigma=Sig, log = T)
      #(exp(kua1-kua3)+exp(kua2-kua3))/2  #checked
      
      miu=mius[j]
      if(ga==2){
        miu=c(rep(miu,n))
      }else{
        llll1=t(t(as.vector(rep(1,n))))
        miu=D%*%llll1*abs(sum(stZ))/c((t(llll1)%*%D%*%llll1))
      }
      a=c(); b=c(); b2=c()
      mRm=t(miu)%*%soD%*%miu
      mR=t(miu)%*%soD
      mRZ=mR%*%t(Z)
      ww[,j]=as.vector(exp(-0.5*(mRm[1,1]-2*mRZ)))
      miu=-miu
      mRm=t(miu)%*%soD%*%miu
      mR=t(miu)%*%soD
      mRZ=mR%*%t(Z)
      ww[,j]=0.5*(ww[,j]+as.vector(exp(-0.5*(mRm[1,1]-2*mRZ))))
    }
    if(ga>2){
      br=mius[j]
      lll=exp((x^2-(x-br)^2)/2)
      lll2=exp((x^2-(x+br)^2)/2)      
      ww[,j]=0.5*(colMeans(lll)+colMeans(lll2))
    }
  }
  wei=1/ww%*%wga
  
  #p SPU
  spu=matrix(nrow=B+1,ncol=length(Ga))
  for(j in 1:length(Ga)){
    ga=Ga[j]
    if(ga<100){
      spu[1,j]=sum(stZ^ga)
      spu[-1,j]=rowSums(Z^ga)
    }
    else{
      spu[1,j]=max(abs(stZ))
      spu[-1,j]=apply(abs(Z),1,max)
    }
  }
  
  pspu=matrix(nrow=B+1,ncol=length(Ga))
  for(j in 1:length(Ga)){
    pspu[1,j]=sum(wei*(abs(spu[-1,j])>abs(spu[1,j])))/B   
  }
  spu1=abs(spu[-1,])
  for(j in 1:length(Ga)){
    rank2=rank(spu1[,j])
    wei2=wei[order(spu1[,j],decreasing=TRUE)]
    wei3=c(); wei3[1]=wei2[1]
    for(i in 2:(B-1)){
      wei3[i]=wei3[i-1]+wei2[i]
    }
    wei3=wei3/(B-1)
    wei3=c(0,wei3)
    wei4=wei3[B:1]
    pspu[2:(B+1),j]=wei4[rank2]
  }
  
  aspu=c()
  for(i in 1:(B+1)){
    aspu[i]=min(pspu[i,])
  }
  
  paspu=sum(wei*(aspu[-1]<aspu[1]))/B 
  
  s2=Sys.time()
  
  #return(list(c(pspu[1,],paspu),as.numeric(s2)-as.numeric(s1)))
  return(c(pspu[1,],paspu))
}


aimp0=function(stZ,D,B,Ga,wga,ddd){
  s1=Sys.time()
  
  
  n=length(stZ)
  Sig=D
  soD=solve(D)
  eS <- eigen(D, symmetric = TRUE)
  ev <- eS$values
  CovSsqrt <- eS$vectors %*% diag(sqrt(pmax(ev, 0)), n)
  
  PP=matrix(nrow=B+1,ncol=length(Ga))
  
  wei=c()
  Z=matrix(nrow=B,ncol=n)
  
  mius=c()
  for(i in 1:length(Ga)){
    ga=Ga[i]
    if(ga<=2){
      mius[i]=(sum(stZ^ga)/n)^(1/ga)/ddd
    }
    else{
      if(ga<Inf){
        mius[i]=(sum(stZ^ga))^(1/ga)/ddd      
      }
      else{
        mius[i]=max(abs(stZ))/ddd
      }
    }
  }
  
  conM=list()
  conDsqrt=list()
  for(t in 1:n){
    S11=Sig[-t,-t]
    S12=Sig[-t,t]
    conM[[t]]=S12
    LL=S11-S12%*%t(S12)
    eS <- eigen(LL, symmetric = TRUE)
    ev <- eS$values
    LS <- eS$vectors %*% diag(sqrt(pmax(ev, 0)), n-1)
    conDsqrt[[t]]=LS
  }
  
  aa=sample(1:length(Ga),B,prob=wga,replace=TRUE)
  tt=sample(1:n,B,replace=TRUE)
  pm=sample(c(-1,1),B,replace=TRUE)
  
  for(i in 1:B){
    a=aa[i]
    ga=Ga[a]
    
    if(ga<=2){
      z1=CovSsqrt%*%rnorm(n)+mius[a]*pm[i]
    }
    if(ga>2){
      z1=c()
      t=tt[i]
      z1[t]=rnorm(1)+mius[a]*pm[i]
      miunew=rep(0,n-1)+conM[[t]]*z1[t]
      Signew=conDsqrt[[t]]
      ll=c(1:n)[-t]
      z1[ll]=Signew%*%rnorm(n-1)+miunew
    }
    Z[i,]=z1
  }
  
  #weight
  ww=matrix(nrow=B,ncol=length(Ga))
  x=t(Z)
  for(j in 1:length(Ga)){
    ga=Ga[j]
    if(ga<=2){
      miu=mius[j]
      miu=rep(miu,n)
      a=c(); b=c(); b2=c()
      mRm=t(miu)%*%soD%*%miu
      mR=t(miu)%*%soD
      mRZ=mR%*%t(Z)
      ww[,j]=as.vector(exp(-0.5*(mRm[1,1]-2*mRZ)))
      miu=-miu
      mRm=t(miu)%*%soD%*%miu
      mR=t(miu)%*%soD
      mRZ=mR%*%t(Z)
      ww[,j]=0.5*(ww[,j]+as.vector(exp(-0.5*(mRm[1,1]-2*mRZ))))
    }
    if(ga>2){
      br=mius[j]
      lll=exp((x^2-(x-br)^2)/2)
      lll2=exp((x^2-(x+br)^2)/2)      
      ww[,j]=0.5*(colMeans(lll)+colMeans(lll2))
    }
  }
  wei=1/ww%*%wga
  
  
  #p SPU
  spu=matrix(nrow=B+1,ncol=length(Ga))
  for(j in 1:length(Ga)){
    ga=Ga[j]
    if(ga!=Inf){
      spu[1,j]=sum(stZ^ga)
      spu[-1,j]=rowSums(Z^ga)
    }
    else{
      spu[1,j]=max(abs(stZ))
      spu[-1,j]=apply(abs(Z),1,max)
    }
  }
  
  se=c()
  pspu=matrix(nrow=B+1,ncol=length(Ga))
  for(j in 1:length(Ga)){
    pspu[1,j]=sum(wei*(abs(spu[-1,j])>abs(spu[1,j])))/B 
    s=sum((wei*(abs(spu[-1,j])>abs(spu[1,j]))-pspu[1,j])^2)/(B-1)
    se[j]=sqrt(s/B)
  }
  
  s2=Sys.time()
  return(list(pspu[1,],wei,spu))
  
}


